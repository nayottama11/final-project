import "./Navbar.css";

const Navbar = () => {
  return (
    <div>
      <header className=" header flex">
        <div>
            <a href="" className="flex">
                <h1>Tama</h1>
            </a>
        </div>

        <div className="navbar">
            <ul className="flex">
                <li>
                    <a href="">Home</a>
                </li>
                <li>
                    <a href="">Home</a>
                </li>
                <li>
                    <a href="">Home</a>
                </li>
                <li>
                    <a href="">Home</a>
                </li>
                <li>
                    <a href="">Home</a>
                </li>

                <button>
                    <a href="">Book Now</a>
                </button>
            </ul>
        </div>

        <div className="toggleNavbar"></div>

      </header>
    </div>
  );
};

export default Navbar;
